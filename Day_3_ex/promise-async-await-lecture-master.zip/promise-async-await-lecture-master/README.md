Code examples used in the two videos related to Promises and async-await
