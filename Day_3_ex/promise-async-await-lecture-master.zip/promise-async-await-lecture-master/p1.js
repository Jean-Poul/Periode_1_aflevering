
console.log("First");
setTimeout(() => console.log("Hello Number 1"), 2000)
console.log("aaaaaa");
setTimeout(() => console.log("Hello Number 2"), 1000)
console.log("bbbbbb");
setTimeout(() => console.log("Hello Number 3"), 500)
console.log("Last");

